String sendHTML_main() //文件固件丢失提示界面，备用页面
{
  String webpage_html;
  webpage_html += "<!DOCTYPE html>";
  webpage_html += "<html lang='zh-CN'>";
  webpage_html += "<head>";
  webpage_html += "<title>天气墨水屏</title>";
  webpage_html += "<meta charset='utf-8'>";
  webpage_html += "<meta name='viewport' content='width=device-width, initial-scale=1'>";
  webpage_html += "</head>";
  webpage_html += "<body>";
  webpage_html += "<h3>糟糕！无法找到该页面，可能原因如下：</h3>";
  webpage_html += "<p>1.文件丢失<br>2.或没有该页面<br>3.或与程序固件不匹配！<p><br>";
  webpage_html += "<p>如需上传固件，请确保8266和设备在同一WIFI网络下！</p>";
  webpage_html += "<p>注意电量，以免在上传过程丢失固件！</p>";
  webpage_html += "<p>需要版本：" + version + "</p>";
  webpage_html += "当前电压：" + String(get_bat_vcc_nwe()) + " V<br>";
  webpage_html += "<p>http://" + WiFi.localIP().toString() + "/update</p>";
  webpage_html += "<a href=\"http://" + WiFi.localIP().toString() + "/update\">";
  webpage_html += "<button type='button'>点击进入更新页面</button>";
  webpage_html += "</a>";
  webpage_html += "<body>";
  webpage_html += "</body>";
  webpage_html += "</html>";

  return webpage_html;
}

String sendHTML_return_home(String xiaoxi) //返回首页
{
  String webpage_html;
  webpage_html += "<!DOCTYPE html>";
  webpage_html += "<html lang='zh-CN'>";
  webpage_html += "<head>";

  webpage_html += "<meta charset='utf-8'>";
  webpage_html += "<meta name='viewport' content='width=device-width, initial-scale=1'>";
  webpage_html += "<link rel='stylesheet' type='text/css' href='bootstrap.css'>";
  webpage_html += "<title>天气墨水屏配置</title>";
  webpage_html += "</head>";
  webpage_html += "<body>";

  webpage_html += "<br>";
  webpage_html += "<div class='row' style='text-align:center;'>";
  webpage_html += "<div class='col'>";
  webpage_html += "<h3>" + xiaoxi + "</h3>";
  webpage_html += "</div>";
  webpage_html += "</div>";

  webpage_html += "<div class='row' style='text-align:center;'>";
  webpage_html += "<div class='col'>";
  webpage_html += "<a href='/'>";
  webpage_html += "<button type='button' class='btn btn-success'>返回首页</button>";
  webpage_html += "</a>";
  webpage_html += "</div>";

  webpage_html += "<div class='col'> ";
  webpage_html += "<a href='/RESET'>";
  webpage_html += "<button type='button' class='btn btn-info'>重启</button>";
  webpage_html += "</a>";
  webpage_html += "</div>";
  webpage_html += "</div>";

  webpage_html += "</body>";
  webpage_html += "</html>";
  return webpage_html;
}
