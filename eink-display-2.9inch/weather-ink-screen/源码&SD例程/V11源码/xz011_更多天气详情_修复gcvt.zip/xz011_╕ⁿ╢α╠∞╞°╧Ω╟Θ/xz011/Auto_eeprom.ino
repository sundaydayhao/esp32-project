//首次开机自动刷写EEPROM
void auto_eeprom()
{
  ESP.rtcUserMemoryRead(RTCdz_peiwang_state, &RTC_peiwang_state, sizeof(RTC_peiwang_state));
  Serial.print("读取 RTC_peiwang_state数据："); Serial.println(RTC_peiwang_state); Serial.println(" ");
  
  //自动计算需要用多少eeprom数量
  EEPROM.begin(sizeof(MyEEPROMStruct));
  //获取eeprom数据
  EEPROM.get(eeprom_address, eeprom);
  if (eeprom.auto_state != 1) eeprom.auto_state = 0;
  if (eeprom.auto_state == 0)
  {
    eeprom.auto_state = 1;  //自动刷写eeprom状态 0-需要 1-不需要

    //为将要存储在EEPROM中的内容设置初始值(默认值)
    eeprom.city[64] = {0};                //城市
    eeprom.weatherKey[64] = {0};          //天气key
    eeprom.nightUpdata = 0;               //夜间更新 1-更新 0-不更新
    eeprom.inAWord[64] = {0};             //自定义一句话，默认 By 甘草酸不酸
    eeprom.screenType = screenType_029A1; //屏幕类型，默认029A1
    eeprom.batDisplayType = 1;            //电池显示类型 0-电压 1-百分比
    strcpy(eeprom.inAWord, String("By 甘草酸不酸").c_str());

    EEPROM.put(eeprom_address, eeprom);
    EEPROM.commitReset(); //首次保存覆盖掉旧的数值
    Serial.println("EEPROM put"); Serial.println("EEPROM put");
  }
  if (eeprom.auto_state == 1)
  {
    EEPROM.get(eeprom_address, eeprom);
    Serial.println("EEPROM get"); Serial.println("EEPROM get");
    //Serial.print("eeprom.weatherKey:"); Serial.println(eeprom.weatherKey);
    //Serial.print("eeprom.city:"); Serial.println(eeprom.city);
  }
  //选择屏幕类型
  //if (eeprom.screenType == screenType_029A1)
  //  GxEPD2_BW<GxEPD2_290, GxEPD2_290::HEIGHT> display(GxEPD2_290(/*CS=D8*/ 15, /*DC=D3*/ 0, /*RST=D4*/ 2, /*BUSY=D2*/ 4)); // GDEH029A1
  //else if (eeprom.screenType == screenType_029T5)
  //  GxEPD2_BW<GxEPD2_290_T5, GxEPD2_290_T5::HEIGHT> display(GxEPD2_290_T5(/*CS=D8*/ 15, /*DC=D3*/ 0, /*RST=D4*/ 2, /*BUSY=D2*/ 4)); // GDEW029T5
  //else if (eeprom.screenType == screenType_029T94)
  //  GxEPD2_BW<GxEPD2_290_T94, GxEPD2_290_T94::HEIGHT> display(GxEPD2_290_T94(/*CS=D8*/ 15, /*DC=D3*/ 0, /*RST=D4*/ 2, /*BUSY=D2*/ 4)); // GDEM029T94
  //else if (eeprom.screenType == screenType_029M06)
  //{
  //GxEPD2_BW<GxEPD2_290_M06, GxEPD2_290_M06::HEIGHT> display(GxEPD2_290_M06(/*CS=D8*/ 15, /*DC=D3*/ 0, /*RST=D4*/ 2, /*BUSY=D2*/ 4)); // GDEW029M06
  // GxEPD2_BW<GxEPD2_213_B72, GxEPD2_213_B72::HEIGHT> display(GxEPD2_213_B72(/*CS=D8*/ 15, /*DC=D3*/ 0, /*RST=D4*/ 2, /*BUSY=D2*/ 4)); // GDEH0213B72
  //}
  Serial.print("屏幕类型："); Serial.println(eeprom.screenType);
}
